import React, { useState, useEffect } from 'react';
import { getWeatherData } from './utils/weatherApi';
import WeatherSummary from './components/WeatherSummary';
import WeatherForecast from './components/WeatherForecast';
import SunMoonInfo from './components/SunMoonInfo';
import HourlyForecast from './components/HourlyForecast';
import CitySearch from './components/CitySearch';

export default function App() {
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [city, setCity] = useState('Istanbul');

  useEffect(() => {
    fetchWeatherData(city);
  }, [city]);

  async function fetchWeatherData(cityName: string) {
    try {
      setLoading(true);
      const data = await getWeatherData(cityName);
      setWeatherData(data);
      setError(null);
    } catch (err) {
      setError('Hava durumu verileri alınamadı');
      setWeatherData(null);
    } finally {
      setLoading(false);
    }
  }

  const handleSearch = (searchCity: string) => {
    setCity(searchCity);
  };

  return (
    <div className="container mx-auto px-4 py-8 bg-gray-100 min-h-screen">
      <h1 className="text-4xl font-bold mb-6 text-center text-gray-800">Hava Durumu</h1>
      <CitySearch onSearch={handleSearch} />
      {loading && <p className="text-center">Yükleniyor...</p>}
      {error && <p className="text-center text-red-500">{error}</p>}
      {weatherData && (
        <div className="space-y-6">
          <WeatherSummary data={weatherData} />
          <WeatherForecast data={weatherData} />
          <SunMoonInfo sunrise={weatherData.city.sunrise} sunset={weatherData.city.sunset} />
          <HourlyForecast data={weatherData} />
        </div>
      )}
    </div>
  );
}

