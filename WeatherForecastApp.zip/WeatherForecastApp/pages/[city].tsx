import React from 'react';
import { GetServerSideProps } from 'next';
import Layout from '../components/Layout';
import SearchBar from '../components/SearchBar';
import WeatherSummary from '../components/WeatherSummary';
import WeatherForecast from '../components/WeatherForecast';
import { getWeatherData } from '../utils/weatherApi';
import { useRouter } from 'next/router';

interface CityPageProps {
  weatherData: any;
  city: string;
}

export default function CityPage({ weatherData, city }: CityPageProps) {
  const router = useRouter();

  if (!weatherData) {
    return <div>Hava durumu verileri yüklenemedi.</div>;
  }

  const handleSearch = (searchCity: string) => {
    router.push(`/${searchCity.toLowerCase()}`);
  };

  return (
    <Layout
      title={`${city} Hava Durumu - 15 Günlük Tahmin`}
      description={`${city} için 15 günlük hava durumu tahmini, saatlik hava durumu ve detaylı bilgiler.`}
      weatherCondition={weatherData.list[0].weather[0].main}
    >
      <SearchBar onSearch={handleSearch} />
      <WeatherSummary data={weatherData} />
      <WeatherForecast data={weatherData} />
    </Layout>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const { city } = context.params as { city: string };
  try {
    const weatherData = await getWeatherData(city);
    return {
      props: { weatherData, city },
    };
  } catch (error) {
    console.error('Error fetching weather data:', error);
    return {
      props: { weatherData: null, city },
    };
  }
};

