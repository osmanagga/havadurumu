import React from 'react';
import Image from 'next/image';

interface AnimatedBackgroundProps {
  weatherCondition: string;
}

export default function AnimatedBackground({ weatherCondition }: AnimatedBackgroundProps) {
  return (
    <div className="fixed top-0 left-0 right-0 bottom-0 -z-10">
      <Image
        src="https://images.rawpixel.com/image_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTA1L2Zyc2t5X2Nsb3Vkc19zcHJpbmdfY2xvdWRzLWltYWdlLWt5YmNvZTh4LmpwZw.jpg"
        layout="fill"
        objectFit="cover"
        quality={100}
        alt="Sky background"
      />
      <div className={`absolute inset-0 bg-gradient-to-br ${getOverlay(weatherCondition)}`} />
    </div>
  );
}

function getOverlay(condition: string): string {
  switch (condition.toLowerCase()) {
    case 'clear':
      return 'from-blue-400/30 to-blue-600/30';
    case 'clouds':
      return 'from-gray-400/30 to-gray-600/30';
    case 'rain':
      return 'from-blue-700/30 to-blue-900/30';
    case 'snow':
      return 'from-blue-100/30 to-blue-300/30';
    default:
      return 'from-blue-400/30 to-blue-600/30';
  }
}

