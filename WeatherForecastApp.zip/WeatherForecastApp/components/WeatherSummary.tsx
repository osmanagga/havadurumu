import React from 'react';
import { motion } from 'framer-motion';
import { translateWeather, getWeatherIcon } from '../utils/weatherTranslations';

interface WeatherSummaryProps {
  data: any;
}

export default function WeatherSummary({ data }: WeatherSummaryProps) {
  const currentWeather = data.list[0];
  const weatherDescription = translateWeather(currentWeather.weather[0].description);
  const weatherIcon = getWeatherIcon(currentWeather.weather[0].description);

  return (
    <motion.div
      className="bg-white bg-opacity-20 backdrop-blur-md rounded-3xl p-8 mb-8 text-white"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h2 className="text-4xl font-bold mb-4">{data.city.name}</h2>
      <div className="flex items-center mb-6">
        <span className="text-8xl mr-6">{weatherIcon}</span>
        <div>
          <p className="text-3xl font-semibold">{weatherDescription}</p>
          <p className="text-6xl font-bold">{Math.round(currentWeather.main.temp)}°C</p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4 text-lg">
        <div>Rüzgar: {currentWeather.wind.speed} km/sa</div>
        <div>Nem: {currentWeather.main.humidity}%</div>
        <div>Basınç: {currentWeather.main.pressure} hPa</div>
        <div>Hissedilen: {Math.round(currentWeather.main.feels_like)}°C</div>
      </div>
    </motion.div>
  );
}

