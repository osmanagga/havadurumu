import React from 'react';
import { translateWeather, getWeatherIcon } from '../utils/weatherTranslations';

interface WeatherSummaryProps {
  data: any;
}

export default function WeatherSummary({ data }: WeatherSummaryProps) {
  const currentWeather = data.list[0];
  const weatherDescription = translateWeather(currentWeather.weather[0].description);
  const weatherIcon = getWeatherIcon(currentWeather.weather[0].description);

  return (
    <div className="bg-white shadow-lg rounded-lg p-6 mb-6">
      <h2 className="text-3xl font-bold mb-4">{data.city.name}</h2>
      <div className="flex items-center mb-4">
        <span className="text-6xl mr-4">{weatherIcon}</span>
        <div>
          <p className="text-2xl font-semibold">{weatherDescription}</p>
          <p className="text-4xl font-bold">{Math.round(currentWeather.main.temp)}°C</p>
        </div>
      </div>
      <ul className="grid grid-cols-2 gap-4">
        <li>Rüzgar: {currentWeather.wind.speed} km/sa</li>
        <li>Nem: {currentWeather.main.humidity}%</li>
        <li>Basınç: {currentWeather.main.pressure} hPa</li>
        <li>Hissedilen: {Math.round(currentWeather.main.feels_like)}°C</li>
      </ul>
    </div>
  );
}

