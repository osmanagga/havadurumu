import React from 'react';
import { translateWeather, getWeatherIcon } from '../utils/weatherTranslations';

interface WeatherForecastProps {
  data: any;
}

export default function WeatherForecast({ data }: WeatherForecastProps) {
  const groupedForecast = data.list.reduce((acc: any, item: any) => {
    const date = new Date(item.dt * 1000).toLocaleDateString('tr-TR');
    if (!acc[date]) {
      acc[date] = item;
    } else if (item.main.temp_max > acc[date].main.temp_max) {
      acc[date].main.temp_max = item.main.temp_max;
    }
    if (item.main.temp_min < acc[date].main.temp_min) {
      acc[date].main.temp_min = item.main.temp_min;
    }
    return acc;
  }, {});

  const dailyForecast = Object.values(groupedForecast);

  return (
    <div className="bg-white shadow-lg rounded-lg p-6">
      <h3 className="text-2xl font-bold mb-4">15 Günlük Hava Tahmini</h3>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b-2 border-gray-200">
              <th className="p-2 text-left">Tarih</th>
              <th className="p-2 text-left">Hava</th>
              <th className="p-2 text-right">Gün</th>
              <th className="p-2 text-right">Gece</th>
              <th className="p-2 text-right">Yağış</th>
            </tr>
          </thead>
          <tbody>
            {dailyForecast.slice(0, 15).map((day: any, index: number) => (
              <tr key={index} className="border-b border-gray-100">
                <td className="p-2">{new Date(day.dt * 1000).toLocaleDateString('tr-TR', { weekday: 'short', day: 'numeric', month: 'numeric' })}</td>
                <td className="p-2">
                  <div className="flex items-center">
                    <span className="mr-2">{getWeatherIcon(day.weather[0].description)}</span>
                    {translateWeather(day.weather[0].description)}
                  </div>
                </td>
                <td className="p-2 text-right">{Math.round(day.main.temp_max)}°C</td>
                <td className="p-2 text-right">{Math.round(day.main.temp_min)}°C</td>
                <td className="p-2 text-right">{Math.round(day.pop * 100)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

