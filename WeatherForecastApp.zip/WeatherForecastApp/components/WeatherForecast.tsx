import React from 'react';
import { motion } from 'framer-motion';
import { translateWeather, getWeatherIcon } from '../utils/weatherTranslations';

interface WeatherForecastProps {
  data: any;
}

export default function WeatherForecast({ data }: WeatherForecastProps) {
  const dailyForecast = data.list.filter((_: any, index: number) => index % 8 === 0).slice(0, 15);

  return (
    <motion.div
      className="bg-white bg-opacity-20 backdrop-blur-md rounded-3xl p-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h3 className="text-2xl font-bold mb-6 text-white">15 Günlük Hava Tahmini</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {dailyForecast.map((day: any, index: number) => (
          <motion.div
            key={index}
            className="bg-white bg-opacity-10 rounded-2xl p-4 text-white"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <p className="text-sm font-semibold mb-2">
              {new Date(day.dt * 1000).toLocaleDateString('tr-TR', { weekday: 'short', day: 'numeric', month: 'numeric' })}
            </p>
            <div className="flex items-center justify-between mb-2">
              <span className="text-3xl">{getWeatherIcon(day.weather[0].description)}</span>
              <div className="text-right">
                <p className="text-sm font-semibold">{Math.round(day.main.temp_max)}°</p>
                <p className="text-xs opacity-70">{Math.round(day.main.temp_min)}°</p>
              </div>
            </div>
            <p className="text-xs">{translateWeather(day.weather[0].description)}</p>
            <p className="text-xs mt-2">Yağış: {Math.round(day.pop * 100)}%</p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

