const weatherTranslations: { [key: string]: string } = {
  'clear sky': 'Açık',
  'few clouds': 'Az Bulutlu',
  'scattered clouds': 'Parçalı Bulutlu',
  'broken clouds': 'Çok Bulutlu',
  'shower rain': 'Sağanak Yağışlı',
  'rain': 'Yağmurlu',
  'thunderstorm': 'Gök Gürültülü Fırtına',
  'snow': 'Karlı',
  'mist': 'Sisli',
  'overcast clouds': 'Kapalı Bulutlu',
  'light rain': 'Hafif Yağmurlu',
  'moderate rain': 'Orta Şiddetli Yağmurlu',
  'heavy intensity rain': 'Şiddetli Yağmurlu',
  'very heavy rain': 'Çok Şiddetli Yağmurlu',
  'extreme rain': 'Aşırı Yağmurlu',
  'freezing rain': 'Dondurucu Yağmurlu',
  'light intensity shower rain': 'Hafif Sağanak Yağışlı',
  'heavy intensity shower rain': 'Şiddetli Sağanak Yağışlı',
  'light snow': 'Hafif Karlı',
  'heavy snow': 'Yoğun Karlı',
  'sleet': 'Karla Karışık Yağmurlu',
  'light shower sleet': 'Hafif Karla Karışık Sağanak',
  'shower sleet': 'Karla Karışık Sağanak',
  'light rain and snow': 'Hafif Yağmur ve Kar',
  'rain and snow': 'Yağmur ve Kar',
  'light shower snow': 'Hafif Kar Sağanağı',
  'shower snow': 'Kar Sağanağı',
  'heavy shower snow': 'Yoğun Kar Sağanağı',
};

export function translateWeather(description: string): string {
  return weatherTranslations[description.toLowerCase()] || description;
}

export function getWeatherIcon(description: string): string {
  const iconMap: { [key: string]: string } = {
    'clear sky': '☀️',
    'few clouds': '🌤️',
    'scattered clouds': '⛅',
    'broken clouds': '☁️',
    'shower rain': '🌧️',
    'rain': '🌦️',
    'thunderstorm': '⛈️',
    'snow': '❄️',
    'mist': '🌫️',
    'overcast clouds': '☁️',
    'light rain': '🌦️',
    'moderate rain': '🌧️',
    'heavy intensity rain': '🌧️',
    'very heavy rain': '🌧️',
    'extreme rain': '🌧️',
    'freezing rain': '🌧️❄️',
    'light intensity shower rain': '🌦️',
    'heavy intensity shower rain': '🌧️',
    'light snow': '🌨️',
    'heavy snow': '❄️',
    'sleet': '🌧️❄️',
    'light shower sleet': '🌧️❄️',
    'shower sleet': '🌧️❄️',
    'light rain and snow': '🌧️❄️',
    'rain and snow': '🌧️❄️',
    'light shower snow': '🌨️',
    'shower snow': '🌨️',
    'heavy shower snow': '❄️',
  };
  return iconMap[description.toLowerCase()] || '🌡️';
}

